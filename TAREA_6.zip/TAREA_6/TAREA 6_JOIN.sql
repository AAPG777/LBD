use Practica2

SELECT Carrera.IDCarrera, Clubs.IDClub
FROM Carrera
INNER JOIN Clubs
ON Carrera.IDCarrera=Clubs.IDClub;

SELECT Alumnos.Matricula, Libros.ID
FROM Alumnos
INNER JOIN Libros
ON Alumnos.Matricula= Libros.ID;
 
SELECT Carrera.IDCarrera, Clubs.IDClub
FROM Carrera
INNER JOIN Clubs
ON Carrera.IDCarrera=Clubs.IDClub;

SELECT Maestros2.FechaNacimiento,Alumnos.FechaNacimiento
FROM Maestros2
INNER JOIN Alumnos
ON Maestros2.FechaNacimiento=Alumnos.FechaNacimiento;

SELECT Maestros2.PrimerApellido,Alumnos.SegundoApellido
FROM Maestros2
INNER JOIN Alumnos
ON Maestros2.PrimerApellido=Alumnos.SegundoApellido;

SELECT PELICULAS.Nombre,PLATILLOS.Nombre
FROM PELICULAS
INNER JOIN PLATILLOS
ON PELICULAS.Nombre=PLATILLOS.Nombre;

SELECT PELICULAS.Precio, PLATILLOS.Precio
FROM PELICULAS
INNER JOIN PLATILLOS
ON PELICULAS.Precio=PLATILLOS.Precio;
 
SELECT Carrera.IDCarrera, Clubs.IDClub
FROM Carrera
INNER JOIN Clubs
ON Carrera.IDCarrera=Clubs.IDClub;

SELECT Carrera.IDCarrera, Clubs.IDClub
FROM Carrera
INNER JOIN Clubs
ON Carrera.IDCarrera=Clubs.IDClub;



SELECT Carrera.IDCarrera, Clubs.IDClub
FROM Carrera
INNER JOIN Clubs
ON Carrera.IDCarrera=Clubs.IDClub;