use Practica2


insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('12345', 'BOB', 'GONZALEZ','MARTINEZ', '2/12/1990')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('214738', 'LALO', 'MARTINEZ','L�PEZ', '2/11/1995')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('903475', 'ROBERTO', 'GARC�A','PESINA', '1/11/1997')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('874235', 'MAR�A', 'GONZALEZ','GARC�A', '2/12/1998')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('83473', 'BOB', 'GONZALEZ','MARTINEZ', '2/12/1999')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('87585', 'TADEO', 'GONZALEZ','MARTINEZ', '2/12/2000')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('14857', 'LUIS', 'GONZALEZ','MARTINEZ', '2/12/2005')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('42345', 'JUAN', 'GONZALEZ','MARTINEZ', '2/12/2002')
insert into Alumnos(Matricula, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento)
values('36345', 'PEDRO', 'GONZALEZ','MARTINEZ', '2/12/1999')
select * from Alumnos

insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'CALDO','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'POLLO','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'SOPA','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'SALAD P','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'SALAD C','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'PECHUGA','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'RES','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values( NEWID(),'FILETE','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'CHILAQ','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'POZOL','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'HUVcTOC','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'HUEVOS','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'OMELT','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'CUPCAKE','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'CAKE','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'HELADO','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'PIE','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'RAMEN','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'TOTOPOS','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'ARROZ','$200', '1/20/2018', '00:00:00')
insert into PLATILLOS(ID,Nombre,Precio,FechaPedido, TiempoNServ)
values ( NEWID(),'MOLE','$200', '1/20/2018', '00:00:00')
select * from PLATILLOS

insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('123345','S','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('07648','A','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('17648','K','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('37648','R','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('487543','Z','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('12390','L','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('42178','A','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('32753','M','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('75823','C','12/12/1990', '10/10/2005', '$400','A')
insert into Libros(ID,Autor,FechaDLanz,FechaDREcib,Precio,Categor�a)
values('12348','S','12/12/1990', '10/10/2005', '$400','A')
select * from Libros

insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','R','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','A','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','B','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','C','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','H','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','D','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','U','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','O','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','F','00:30:00','145')
insert into Clubs(IDClub,Nombre,Encargado,Duraci�n,Aula)
values(NEWID(),'CAD','S','00:30:00','145')
select * from Clubs

insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'LSTI','110','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'LMAD','150','70','00:30:00','149,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'SFD','100','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'JH','130','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'JFD','120','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'FGI','100','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'HHT','190','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'KUYI','110','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'XWI','180','40','00:30:00','145,343')
insert into Carrera(IDCarrera, Nombre,NumeroEstud,Grupos,Duraci�nTotal,Aulas)
values(NEWID(),'ASD','190','40','00:30:00','145,343')
select * from Carrera

insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('1234','HALO','B','1/20/2005','$145','M')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('23456','SONIC','S','1/20/2005','$145','E')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('12345','MARIO','N','1/20/2005','$145','E')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('3434','POKEMON','N','1/20/2005','$145','E')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('9234','SMASH','S','1/20/2005','$145','E')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('4234','CRASH','C','1/20/2005','$145','E')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('7234','MARVCAP','C','1/20/2005','$145','T')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('5234','DESTINY','B','1/20/2005','$145','T')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('88234','MEGAMAN','B','1/20/2005','$145','E')
insert into VIDEOJUEGOS(ID,Nombre,Creadores,FechaDentr,Precio,Categor�a)
values('99234','SPYRO','B','1/20/2005','$145','E')
select * from VIDEOJUEGOS

insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('12345','ALIEN','2/2/2005','$200','T','C')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('12346','STARWARS','2/3/2005','$200','S','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('123456','ODISEA','2/2/2005','$200','S','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('76465','AVENGERS','2/2/2005','$200','H','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('09845','XMEN','2/2/2005','$200','H','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('42345','AVATAR','2/2/2005','$200','C','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('52345','SPIDERMAN','2/2/2005','$200','H','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('92345','HULK','2/2/2005','$200','H','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('62345','IRONMAN','2/2/2005','$200','H','B')
insert into PELICULAS(ID,Nombre,FechaDentr,Precio,Categor�a,Clasificaci�n)
values('72345','LOGAN','2/2/2005','$200','H','C')
select * from PELICULAS

insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'WARRIOR','I','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'SPIDERMAN','S','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'MENINBLA','M','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'LIVINON','Q','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'GANGANM','W','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'BLACKNYELL','T','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'NEWYORK','I','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'GANSTA','HG','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'FEELG','I','5/5/2018','$145','B')
insert into MUSICA(ID,Nombre,Autor,FechaDCompr,Precio,Categor�a)
values(NEWID(),'HOPES','I','5/5/2018','$145','B')
select * from MUSICA

insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','BOB','S','3/10/1990','3/3/2005','32'
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','LALO','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','PEDRO','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','HAN','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','JHON','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','JUAN','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','LUCAS','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','TOM','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','ROBERTO','S','00:30:00','145')
insert into Maestros2(NumEmpl,Nombre,PrimerApellido,FechaNacimiento,FechaIngreso,Edad)
values('23456','VALE','S','00:30:00','145')
select * from Maestros2

insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'MATE','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'FIS','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'CC','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'TUT','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'KJK','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'ESP','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'SS','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'INGS','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'IF','S','10','00:30:00','145')
insert into Materia(IDMat,Nombre,Profesor,Grupo,Duraci�n,NomCarrera)
values(NEWID(),'AAR','S','10','00:30:00','145')
select * from Materia

update Clubs
SET Nombre='CAO'
WHERE Encargado='D';

update Clubs
SET Nombre='LOL'
WHERE Encargado='S';

update Clubs
SET Nombre='KHE'
WHERE Encargado='U';

update Clubs
SET Nombre='0W0'
WHERE Encargado='A';

update Clubs
SET Nombre=':3'
WHERE Encargado='F';

update Clubs
SET Nombre='MATE'
WHERE Encargado='B';

update Clubs
SET Nombre='WUT'
WHERE Encargado='O';

update Clubs
SET Nombre='HI'
WHERE Encargado='U';

update Clubs
SET Nombre='KESO'
WHERE Encargado='C';
 
update Clubs
SET Nombre='KCRAISI'
WHERE Encargado='H';

select * from Clubs